from django.shortcuts import render
from products.models import Product

def index(request):
    """A view to return the index page"""
    return render(request, 'home/index.html')

def all_products(request):
    """A view to show all products"""
    products = Product.objects.all()
    return render(request, 'home/all_products.html', {'products': products})