from django.shortcuts import render
from django.conf import settings
from .models import Product

def all_products(request):
    """A view to show all products, including sorting and search queries"""
    products = Product.objects.all()
    
    context = {
        'products': products,
        'MEDIA_URL': settings.MEDIA_URL,
    }
    return render(request, 'products/products.html', context)

def index(request):
    return render(request, 'products/index.html')